#!/bin/bash

# Edit the WORKING_DIR variable
WORKING_DIR=/path/to/pss-genome-fs/working_dir/

# Adjust the COMPI_NUM_TASKS to an appropiate value
COMPI_NUM_TASKS=8

#
# Other pipeline specific parameters can be changed in the pss-genome-fs.params
# file placed at pss-genome-fs/working_dir/
#

docker run --rm -v /tmp:/tmp -v /var/run/docker.sock:/var/run/docker.sock -v ${WORKING_DIR}:/working_dir --rm pegi3s/pss-genome-fs --logs /working_dir/logs --params /working_dir/pss-genome-fs.params --num-tasks ${COMPI_NUM_TASKS} -- --host_working_dir ${WORKING_DIR} --keep_temporary_dir --compi_num_tasks ${COMPI_NUM_TASKS}
